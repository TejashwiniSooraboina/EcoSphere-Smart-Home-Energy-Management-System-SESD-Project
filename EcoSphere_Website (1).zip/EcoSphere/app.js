const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const icons={"Air Conditioner":"❄","Refrigerator":"▣","Living Room Lights":"☼","Television":"▣","Washing Machine":"◉","Ceiling Fan":"✳","Microwave":"▤","Water Heater":"♨"};
let devices=[
{name:"Air Conditioner",room:"Living Room",power:1500,on:true},
{name:"Refrigerator",room:"Kitchen",power:180,on:true},
{name:"Living Room Lights",room:"Living Room",power:45,on:true},
{name:"Television",room:"Living Room",power:110,on:false},
{name:"Washing Machine",room:"Utility",power:500,on:false},
{name:"Ceiling Fan",room:"Bedroom",power:70,on:true},
{name:"Microwave",room:"Kitchen",power:900,on:false},
{name:"Water Heater",room:"Bathroom",power:2000,on:true}
];
try{const saved=JSON.parse(localStorage.getItem("ecos-devices"));if(Array.isArray(saved))devices=saved}catch(e){}
let tariff=Number(localStorage.getItem("ecos-tariff"))||8;
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function iconFor(n){return icons[n]||"ϟ"}
function renderDevices(){
 const online=devices.filter(d=>d.on).length;
 $("#activeCount").textContent=online;$("#deviceSummary").textContent=`${devices.length} devices · ${online} online`;
 const row=d=>`<div class="device-row"><div class="device-icon">${iconFor(d.name)}</div><div class="device-info"><strong>${esc(d.name)}</strong><small>${esc(d.room)} · ${d.on?"Running":"Standby"}</small></div><span class="device-watts">${d.power} W</span><button class="switch ${d.on?"on":""}" aria-label="Toggle ${esc(d.name)}" data-toggle="${esc(d.name)}"></button></div>`;
 $("#devicePreview").innerHTML=devices.slice(0,4).map(row).join("");
 const q=($("#deviceSearch")?.value||"").toLowerCase();
 $("#allDevices").innerHTML=devices.filter(d=>(d.name+" "+d.room).toLowerCase().includes(q)).map(d=>`<article class="device-card"><div class="device-card-top"><div class="device-icon">${iconFor(d.name)}</div><button class="switch ${d.on?"on":""}" aria-label="Toggle ${esc(d.name)}" data-toggle="${esc(d.name)}"></button></div><h3>${esc(d.name)}</h3><p>${esc(d.room)} · ${d.on?"Currently running":"Currently off"}</p><div class="device-card-bottom"><div><strong>${d.power} W</strong><small>Rated power</small></div><span class="pill">${d.on?"ONLINE":"OFFLINE"}</span></div></article>`).join("")||'<p>No devices found.</p>';
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function save(){localStorage.setItem("ecos-devices",JSON.stringify(devices));renderDevices()}
document.addEventListener("click",e=>{
 const toggle=e.target.closest("[data-toggle]");if(toggle){const d=devices.find(x=>x.name===toggle.dataset.toggle);if(d){d.on=!d.on;save();toast(`${d.name} turned ${d.on?"on":"off"} (demo)`)}}
 const nav=e.target.closest("[data-page]");if(nav){e.preventDefault();showPage(nav.dataset.page)}
 const go=e.target.closest("[data-goto]");if(go)showPage(go.dataset.goto);
 const rec=e.target.closest("[data-device]");if(rec){showPage("devices");$("#deviceSearch").value=rec.dataset.device;renderDevices()}
});
function showPage(id){$$(".page").forEach(p=>p.classList.toggle("active",p.id===id));$$(".nav-link[data-page]").forEach(a=>a.classList.toggle("active",a.dataset.page===id));$("#pageName").textContent=({overview:"Overview",devices:"My devices",analytics:"Analytics",bills:"Energy bills",recommendations:"Eco recommendations",settings:"Settings"})[id]||"Overview";location.hash=id;$("#sidebar").classList.remove("open");window.scrollTo(0,0)}
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
function openModal(){$("#modal").classList.add("show");$("#newDeviceName").focus()}
$("#addDevice").onclick=openModal;$("#quickAdd").onclick=openModal;$("#modalClose").onclick=()=>$("#modal").classList.remove("show");
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")$("#modal").classList.remove("show")});
$("#confirmAdd").onclick=()=>{const name=$("#newDeviceName").value.trim(),power=Number($("#newDevicePower").value);if(!name||!power||power<1){toast("Enter a device name and valid wattage.");return}if(devices.some(d=>d.name.toLowerCase()===name.toLowerCase())){toast("That device already exists.");return}devices.push({name,room:$("#newDeviceRoom").value,power,on:false});save();$("#newDeviceName").value="";$("#modal").classList.remove("show");toast("Device added to demo dashboard.")};
$("#deviceSearch").addEventListener("input",renderDevices);
$("#chartRange").onchange=e=>{const month=e.target.value==="month";$("#chartTotal").textContent=month?"551 kWh total":"126.8 kWh total";$("#xLabels").innerHTML=(month?["Week 1","Week 2","Week 3","Week 4","Now"]:["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]).map(x=>`<span>${x}</span>`).join("");toast(month?"Showing monthly sample trend":"Showing weekly sample trend")};
const barData=[16,20,18,24,15,19,14];$("#barChart").innerHTML=barData.map((v,i)=>`<div class="bar-item"><b>${v} kWh</b><i style="height:${v/27*70}%"></i><small>${["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i]}</small></div>`).join("");
function csvDownload(name,rows){const csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(",")).join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download=name;a.click();URL.revokeObjectURL(a.href)}
function exportDevices(){csvDownload("ecos­phere-energy-devices.csv",[["Device","Room","Rated power (W)","Status"],...devices.map(d=>[d.name,d.room,d.power,d.on?"On":"Off"])])}
$("#exportCsv").onclick=exportDevices;$("#billExport").onclick=()=>csvDownload("ecos­phere-energy-bills.csv",[["Month","Consumption (kWh)","Estimated cost (INR)"],["November",551,551*tariff],["October",578,4624],["September",612,4896],["August",590,4720],["July",635,5080]]);
$("#tariff").value=tariff;$("#saveSettings").onclick=()=>{tariff=Math.max(0,Number($("#tariff").value)||0);localStorage.setItem("ecos-tariff",tariff);localStorage.setItem("ecos-home",$("#homeName").value);$("#settingsMessage").textContent="Preferences saved in this browser.";toast("Settings saved.")};
$("#homeName").value=localStorage.getItem("ecos-home")||"Eco Home";
if(location.hash&&$("#"+location.hash.slice(1)))showPage(location.hash.slice(1));else showPage("overview");
renderDevices();