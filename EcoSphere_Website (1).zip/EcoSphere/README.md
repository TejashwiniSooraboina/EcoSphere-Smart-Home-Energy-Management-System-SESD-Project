# EcoSphere — Smart Home Energy Management System

A responsive front-end academic prototype built with HTML, CSS and vanilla JavaScript.

## Run in Google Chrome
1. Extract `EcoSphere_Website.zip`.
2. Open `index.html` in Chrome, or use VS Code Live Server.
3. No npm install or server is required.

## Included pages
- Overview dashboard with energy, cost, carbon and device summary
- Device controls (on/off demo state) and add-device modal
- Analytics with weekly chart and CSV export
- Estimated electricity bills and CSV export
- Eco recommendations
- Settings for home name and electricity tariff

## Important project note
This is a front-end demonstration. All readings, bills, carbon savings and charts are sample/demo values. Device toggles update only the browser interface and localStorage; they do not control physical appliances. To make it a real IoT system, connect a backend/API and hardware such as ESP32 with energy-monitoring sensors or smart plugs. Add authentication, database storage, secure device communication and validated meter readings before deployment.

## Suggested next-stage architecture
Frontend: HTML/CSS/JavaScript (or React)
Backend: Python FastAPI / Flask or Node.js
Database: Firebase / PostgreSQL / MongoDB
IoT: ESP32 + PZEM-004T energy meter or certified smart plugs
Forecasting: Python (scikit-learn / TensorFlow) using historical kWh readings
